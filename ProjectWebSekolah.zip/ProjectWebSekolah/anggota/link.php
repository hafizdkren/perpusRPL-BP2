<div class="link_atas"><b><a href="?page=anggota">Lihat Data anggota</a></b>|
<b> <a href="?page=input_anggota">Input anggota baru</a></b>|
<b><a href="?page=anggota">Edit data anggota</a></b>|
<b><a href="?page=anggota">hapus data anggota</a></b>|
<b><a href="?page=anggota">cetak data anggota</a></b>|
<b><a href="?page=cetak_lap_keseluruhan">cetak anggota keseluruhan</a></div>