<div class="link_atas"><b><a href="?page=transaksi">Lihat Data Transaksi</a></b> |
<b><a href="?page=input_transaksi">Input Transaksi Baru</a></b> |
<b><a href="?page=transaksi">Pengembalian Buku</a></b></div>