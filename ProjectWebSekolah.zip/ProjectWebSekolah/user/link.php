
<div class="link_atas"><b><a href="?page=user">Lihat Data User</a></b> |
 <b> <a href="?page=input_user">Input User Baru</a></b> |
 <b><a href="?page=user">Edit Data User</a></b> |
 <b><a href="?page=user">Hapus Data Buku</a></b></div>

 