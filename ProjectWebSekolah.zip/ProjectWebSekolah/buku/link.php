<div class="link_atas"><b><a href="?page=buku">Lihat Data Buku</a></b> |
<b> <a href="?page=input_buku">Input Buku Baru</a></b> |
<b><a href="?page=buku">Edit Data Buku</a></b> |
<b><a href="?page=buku">Hapus Data Buku</a></b></div> 