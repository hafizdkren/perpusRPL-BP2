
<div class="link_atas"><b><a href="?page=lap_pengunjung">Laporan Pengunjung</a></b> | <b> <a href="?page=lap_peminjaman">Laporan Peminjaman Per Siswa</a></b></div>